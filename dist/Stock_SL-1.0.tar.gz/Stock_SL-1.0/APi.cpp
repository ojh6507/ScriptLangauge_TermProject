
#include "Python.h"

// ���̹� //
static PyObject* get_naver_api_key(PyObject* self, PyObject* args) {
	
	return Py_BuildValue("s", "x9NjT2FRk8MvnFKl2u2f");
}
static PyObject* get_naver_api_psw(PyObject* self, PyObject* args) {
	return Py_BuildValue("s", "bE4jGzFWfd");
}
static PyObject* get_KI_api_key(PyObject* self, PyObject* args) {

	return Py_BuildValue("s", "PSi8y6hvV0M0YN5DWPR6xnduteM5Rp6GtagL");
}
static PyObject* get_KI_api_psw(PyObject* self, PyObject* args) {
	return Py_BuildValue("s", "dXHpdzAF7arfSQ8qNkQF8Olc1Lf0H9j1nvcNm5PQCxOxwc1iXwjtgH5DPntP/KWsZGzOw+WDYlfRHd01Rfdbz5pZ1xiCZcgxBnPlMag3QL/zsVC2gpewBjhjYFaPwdosbHi32jyCt2lHpz35fvOoR1TVaqIed234mXB4VA4w4eAGVYT3GMI=");
}
static PyObject* get_CANO(PyObject* self, PyObject* args) {
	return Py_BuildValue("s", "73571774");
}
static PyObject* get_ACNT_PRDT_CD(PyObject* self, PyObject* args) {

	return Py_BuildValue("s", "01");
}
static PyObject* get_URL_Base(PyObject* self, PyObject* args) {

	return Py_BuildValue("s", "https://openapi.koreainvestment.com:9443");
}
static PyObject* get_GoogleMap_KEY(PyObject* self, PyObject* args) {

	return Py_BuildValue("s", "AIzaSyBhIIblhxv6SLpMMNMQjtGFAbQBHW7tEjA");
}
static PyObject* get_telegram_KEY(PyObject* self, PyObject* args) {

    return Py_BuildValue("s", "6058699699:AAHwCAOiALvsKtBelGTjFHI7U7B0oYzoEEQ");
}


static PyMethodDef ApiKeyMethods[] = {
    {"get_naver_api_key",  get_naver_api_key, METH_VARARGS, "Return the Naver API key."},
    {"get_naver_api_psw",  get_naver_api_psw, METH_VARARGS, "Return the Naver API password."},
    {"get_KI_api_key",  get_KI_api_key, METH_VARARGS, "Return the Korea Investment API key."},
    {"get_KI_api_psw",  get_KI_api_psw, METH_VARARGS, "Return the Korea Investment API password."},
    {"get_CANO",  get_CANO, METH_VARARGS, "Return the CANO."},
    {"get_ACNT_PRDT_CD",  get_ACNT_PRDT_CD, METH_VARARGS, "Return the Account Product Code."},
    {"get_URL_Base",  get_URL_Base, METH_VARARGS, "Return the Base URL."},
    {"get_GoogleMap_KEY",  get_GoogleMap_KEY, METH_VARARGS, "Return the Google Map key."},
    {"get_Telegram_KEY",  get_telegram_KEY, METH_VARARGS, "Return the Telegram key."},
    {NULL, NULL, 0, NULL}
};

static struct PyModuleDef apikeymodule = {
    PyModuleDef_HEAD_INIT,
    "apikey",
    NULL,
    -1,
    ApiKeyMethods
};

PyMODINIT_FUNC
PyInit_apikey(void) {
    return PyModule_Create(&apikeymodule);
}
